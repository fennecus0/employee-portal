<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_56674cafdbb738a963b12d735cc021f10638bc769f885bed9abc5c1829bacc97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f2f4e3146bf73951d49f3601797fafd2d1bae21deacdd159cc6bfcec61926bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f2f4e3146bf73951d49f3601797fafd2d1bae21deacdd159cc6bfcec61926bf->enter($__internal_4f2f4e3146bf73951d49f3601797fafd2d1bae21deacdd159cc6bfcec61926bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_b24b830a7fc7a0d1dfa339b626afad11dc84ddac6a350d0e6ce3751133974dbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b24b830a7fc7a0d1dfa339b626afad11dc84ddac6a350d0e6ce3751133974dbc->enter($__internal_b24b830a7fc7a0d1dfa339b626afad11dc84ddac6a350d0e6ce3751133974dbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        
        $__internal_4f2f4e3146bf73951d49f3601797fafd2d1bae21deacdd159cc6bfcec61926bf->leave($__internal_4f2f4e3146bf73951d49f3601797fafd2d1bae21deacdd159cc6bfcec61926bf_prof);

        
        $__internal_b24b830a7fc7a0d1dfa339b626afad11dc84ddac6a350d0e6ce3751133974dbc->leave($__internal_b24b830a7fc7a0d1dfa339b626afad11dc84ddac6a350d0e6ce3751133974dbc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "/var/www/html/portal/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
