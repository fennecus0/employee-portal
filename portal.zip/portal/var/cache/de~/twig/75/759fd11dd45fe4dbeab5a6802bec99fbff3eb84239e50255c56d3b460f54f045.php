<?php

/* FOSUserBundle:Group:new_content.html.twig */
class __TwigTemplate_0460f137ad46986aa464fb53e405fecd5aa590a1110a0c1bf634dcbdfa8ecf80 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67d023ddd499ea2d86b67d383e3b32042bb8f646c573b8002be894c45aa1b93a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_67d023ddd499ea2d86b67d383e3b32042bb8f646c573b8002be894c45aa1b93a->enter($__internal_67d023ddd499ea2d86b67d383e3b32042bb8f646c573b8002be894c45aa1b93a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new_content.html.twig"));

        $__internal_2fec0ac247f3b6053f3c601a13590cfaf3abb4fb00feaa583d2c193617c56d98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fec0ac247f3b6053f3c601a13590cfaf3abb4fb00feaa583d2c193617c56d98->enter($__internal_2fec0ac247f3b6053f3c601a13590cfaf3abb4fb00feaa583d2c193617c56d98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new_content.html.twig"));

        // line 2
        echo "
";
        // line 3
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_group_new"), "attr" => array("class" => "fos_user_group_new")));
        echo "
    ";
        // line 4
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
    <div>
        <input type=\"submit\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("group.new.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
    </div>
";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_67d023ddd499ea2d86b67d383e3b32042bb8f646c573b8002be894c45aa1b93a->leave($__internal_67d023ddd499ea2d86b67d383e3b32042bb8f646c573b8002be894c45aa1b93a_prof);

        
        $__internal_2fec0ac247f3b6053f3c601a13590cfaf3abb4fb00feaa583d2c193617c56d98->leave($__internal_2fec0ac247f3b6053f3c601a13590cfaf3abb4fb00feaa583d2c193617c56d98_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 8,  37 => 6,  32 => 4,  28 => 3,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

{{ form_start(form, { 'action': path('fos_user_group_new'), 'attr': { 'class': 'fos_user_group_new' } }) }}
    {{ form_widget(form) }}
    <div>
        <input type=\"submit\" value=\"{{ 'group.new.submit'|trans }}\" />
    </div>
{{ form_end(form) }}
", "FOSUserBundle:Group:new_content.html.twig", "/var/www/html/portal/app/Resources/FOSUserBundle/views/Group/new_content.html.twig");
    }
}
