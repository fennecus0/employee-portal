<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_fd4321ccf7feecc3eb0506e6ed568a64a32f6f7531f19a2c7512b88168a66662 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9793a358a74ee7f674c25fc07a7c9e0d5d1241bbc214c52e94efb16f4e312264 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9793a358a74ee7f674c25fc07a7c9e0d5d1241bbc214c52e94efb16f4e312264->enter($__internal_9793a358a74ee7f674c25fc07a7c9e0d5d1241bbc214c52e94efb16f4e312264_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_5c55f2ae8226406c91a1fa86da1a9a49d52f520af688945024fc13ea5b3fa38c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c55f2ae8226406c91a1fa86da1a9a49d52f520af688945024fc13ea5b3fa38c->enter($__internal_5c55f2ae8226406c91a1fa86da1a9a49d52f520af688945024fc13ea5b3fa38c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_9793a358a74ee7f674c25fc07a7c9e0d5d1241bbc214c52e94efb16f4e312264->leave($__internal_9793a358a74ee7f674c25fc07a7c9e0d5d1241bbc214c52e94efb16f4e312264_prof);

        
        $__internal_5c55f2ae8226406c91a1fa86da1a9a49d52f520af688945024fc13ea5b3fa38c->leave($__internal_5c55f2ae8226406c91a1fa86da1a9a49d52f520af688945024fc13ea5b3fa38c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/var/www/html/portal/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
