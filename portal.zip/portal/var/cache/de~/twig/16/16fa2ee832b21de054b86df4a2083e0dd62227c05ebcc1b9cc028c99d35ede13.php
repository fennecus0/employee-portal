<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_87b9f9ab36833a68c17b4aeec3b927d19cd63a0acbae2fac817740422b93537c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_274cd45fa3d7f8e66683e3baaacdf8c2b46705960825641555e6bd15d3a17dc2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_274cd45fa3d7f8e66683e3baaacdf8c2b46705960825641555e6bd15d3a17dc2->enter($__internal_274cd45fa3d7f8e66683e3baaacdf8c2b46705960825641555e6bd15d3a17dc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_225322bbf4384972f604801ea42377b3939b2cc120524b7e6c93135f2c8082d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_225322bbf4384972f604801ea42377b3939b2cc120524b7e6c93135f2c8082d5->enter($__internal_225322bbf4384972f604801ea42377b3939b2cc120524b7e6c93135f2c8082d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_274cd45fa3d7f8e66683e3baaacdf8c2b46705960825641555e6bd15d3a17dc2->leave($__internal_274cd45fa3d7f8e66683e3baaacdf8c2b46705960825641555e6bd15d3a17dc2_prof);

        
        $__internal_225322bbf4384972f604801ea42377b3939b2cc120524b7e6c93135f2c8082d5->leave($__internal_225322bbf4384972f604801ea42377b3939b2cc120524b7e6c93135f2c8082d5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/var/www/html/portal/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
